#By opening, viewing, changing, sharing this file you violate usage license agreement.
#This file is property of "FSModUpdare (FSMUP)" & EthanA Videos.
#Author: Ethan.
#Owner: EthanA Videos.
#Creation Date: 12-3-23
#Updated Date: 12-9-23

#!/bin/bash

# Check if Homebrew is installed
if ! command -v brew &> /dev/null; then
    echo "Homebrew is not installed. Please install Homebrew first."
    exit 1
fi

# Check if the package list file exists
if [ -f ".development/packages.txt" ]; then
    # Read the list of packages from the file
    packages=$(cat .development/packages.txt)

    # Loop through each package
    for package in $packages; do
        # Check if the package is installed
        if ! brew list $package &> /dev/null; then
            # Install the package if not installed
            sudo apt-get install $package
        else
            echo "Package $package is already installed."
        fi
    done
else
    echo "Package list file (packages.txt) not found."
fi
