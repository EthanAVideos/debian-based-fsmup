#All Right EthanA Videos, Developer Of This Software.
#Date Made: 9-10-23
#Date Last Updated: 12-09-23
#Version: 2.1.5 

#You are not to open / change this file without written consent from EthanA Videos.

import tkinter as tk
from tkinter import ttk
import os
import zipfile
import xml.etree.ElementTree as ET
import shutil
import threading
import logging
import datetime
import sys

# Configure the logging
logging.basicConfig(filename='.development/log.txt', level=logging.INFO, format='%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

# Function to log messages
def log_message(message):
    logging.info(message)

# Function to log uncaught exceptions
def log_exception(exctype, value, tb):
    formatted_exception = f"!* error: {exctype.__name__}, > {value}, > line: {tb.tb_lineno}"
    log_message(formatted_exception)
    sys.__excepthook__(exctype, value, tb)  # Call the default excepthook to print the error to the terminal

# Set the custom exception handler
sys.excepthook = log_exception

# Function to update mods in a separate thread
def update_mods():
    # Disable the update button while updating
    update_button.config(state=tk.DISABLED)

    # Get the entered descVersion number
    desc_version = entry.get()

    # Get a list of zip files in the "update" folder
    update_folder = "update"
    updated_folder = "updated"

    zip_files = [f for f in os.listdir(update_folder) if f.endswith(".zip")]

    total_files = len(zip_files)
    progress_var.set(0)  # Initialize progress bar value
    result_label.config(text="Updating Mods...")

    # Define a function to update the progress bar
    def update_progress(i):
        progress_percentage = (i / total_files) * 100
        progress_var.set(progress_percentage)
        progress_label.config(text=f"{progress_percentage:.2f}%")  # Show progress percentage
        root.update_idletasks()

    def clear_mod_folder(folder_path):
        # Clear all files and subfolders within the folder
        for root_folder, _, files in os.walk(folder_path):
            for file in files:
                os.remove(os.path.join(root_folder, file))
            for subfolder in os.listdir(root_folder):
                subfolder_path = os.path.join(root_folder, subfolder)
                if os.path.isdir(subfolder_path):
                    shutil.rmtree(subfolder_path)

    for i, zip_file in enumerate(zip_files, start=1):
        try:
            # Construct the paths
            mod_zip_path = os.path.join(update_folder, zip_file)
            mod_folder = os.path.splitext(zip_file)[0]
            mod_folder_path = os.path.join(update_folder, mod_folder)
            updated_mod_zip_path = os.path.join(updated_folder, zip_file)

            # Extract the mod folder
            with zipfile.ZipFile(mod_zip_path, 'r') as zip_ref:
                zip_ref.extractall(mod_folder_path)

            # Parse the modDesc.xml file and update the descVersion
            xml_file_path = os.path.join(mod_folder_path, 'modDesc.xml')
            if os.path.isfile(xml_file_path):
                tree = ET.parse(xml_file_path)
                mod_root = tree.getroot()
                old_version = mod_root.get('descVersion')
                mod_root.set('descVersion', desc_version)  # Use a different variable name for the mod root

                # Write the updated XML
                tree.write(xml_file_path, encoding="utf-8", xml_declaration=True)
                log_message(f"^ {mod_folder} was updated from modDesc Version: {old_version} > modDesc Version: {desc_version}, old file path: {mod_zip_path}, errors: None")

            # Create a new zip file with the updated mod folder
            with zipfile.ZipFile(updated_mod_zip_path, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
                for foldername, subfolders, filenames in os.walk(mod_folder_path):
                    for filename in filenames:
                        file_path = os.path.join(foldername, filename)
                        arcname = os.path.relpath(file_path, mod_folder_path)
                        zip_ref.write(file_path, arcname)
                log_message(f">| {mod_folder} was successfully updated, can be found here: {updated_mod_zip_path}.")

            # Clear the temporary mod folder (remove all files and subfolders)
            clear_mod_folder(mod_folder_path)

            # Remove the temporary mod folder
            os.rmdir(mod_folder_path)

            # Update progress bar
            update_progress(i)
        except Exception as e:
            log_message(f"* Error: {str(e)}")
            log_message(f"* {mod_folder} failed to update > Error: {str(e)}")

    progress_var.set(100)  # Set progress to 100% when done
    result_label.config(text="Mods Updated!")

    # Re-enable the update button
    update_button.config(state=tk.NORMAL)

# Create the main window
root = tk.Tk()
root.title("(EAV) FS Mod Updater (v2.1.5)")

# Set the initial window size (width x height)
window_width = 900
window_height = 600
root.geometry(f"{window_width}x{window_height}")

# Create and configure the label in the right bottom corner
bottom_right_label = tk.Label(root, text="All Right EthanA Videos© 2020 - 2023")
bottom_right_label.place(x=330, y=300)  # Adjust the coordinates as needed

# Create label, apps version
version_label = tk.Label(root, text="Version: 2.1.5")
version_label.place(x=10, y=30)  # Adjust the coordinates as needed

# Create and configure the label in the left top corner with a hyperlink-like cursor
top_left_label = tk.Label(
    root, text="Developed By EthanA Videos", cursor="hand2", foreground="blue")
top_left_label.place(x=10, y=10)  # Adjust the coordinates as needed

# Bind a function to open the hyperlink when the label is clicked
def open_website(event):
    import webbrowser
    webbrowser.open("http://eav.us.to/assets")

top_left_label.bind("<Button-1>", open_website)

# Create and configure the label at the bottom center
result_label = tk.Label(root, text="")
result_label.pack(pady=10)

# Create and configure the label
label = tk.Label(root, text="Place mods in 'update/'. Once updated, they can be found in 'updated/'.")
label.pack(pady=10)

# Create and configure the entry field
entry = tk.Entry(root)
entry.pack(pady=10)

# Create and configure the update button
update_button = tk.Button(root, text="Update Mods", command=lambda: threading.Thread(target=update_mods).start())
update_button.pack(pady=10)

# Create and configure the progress bar
progress_var = tk.DoubleVar()
progress_bar = ttk.Progressbar(root, variable=progress_var, length=window_width - 20)
progress_bar.pack(pady=10)

# Create and configure the progress label
progress_label = tk.Label(root, text="")
progress_label.pack(pady=10)

# Create and configure the result label "Please Be Patient; This process is slow, the more mods the slower."
result_label_slow = tk.Label(root, text="Please Be Patient; This process is slow, the more mods the slower.")
result_label_slow.pack(pady=10)

# Start the main loop
root.mainloop()
