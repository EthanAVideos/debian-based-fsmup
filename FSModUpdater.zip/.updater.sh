#By opening, viewing, changing, sharing this file you violate usage license agreement.
#This file is property of "FSModUpdare (FSMUP)" & EthanA Videos.
#Author: Ethan.
#Owner: EthanA Videos.
#Creation Date: 12-3-23
#Updated Date: 12-9-23

#!/bin/bash

#set -e  # Exit on error
#set -x

# Remote URLs
REMOTE_VERSION_URL="https://raw.githubusercontent.com/EthanAVideos/debian-based-fsmup/main/version.txt"
FSMUP_ZIP_URL="https://github.com/EthanAVideos/debian-based-fsmup/releases/download/12-5-23/FSModUpdater.zip"

# Read the local version from your version file
LOCAL_VERSION=$(cat .version.txt)

# If local version is empty, consider FSMUP up to date
if [ -z "$LOCAL_VERSION" ]; then
    echo "FSMUP is up to date."
    exit 0
fi

# Download the remote version from the provided URL
REMOTE_VERSION=$(curl -s "$REMOTE_VERSION_URL")

# Compare local and remote versions
if [ "$REMOTE_VERSION" != "$LOCAL_VERSION" ]; then
    echo "Update available. Local version: $LOCAL_VERSION, Remote version: $REMOTE_VERSION"

    # Update the local version with the remote version
    echo "$REMOTE_VERSION" > .version.txt

    # Download the new version of FSMUP
    curl -LJO "$FSMUP_ZIP_URL" -o fsmup_new_version.zip

    # Create the destination directory if it doesn't exist
    mkdir -p fsmup_temp

    # Unzip the new version to the temporary directory
    unzip FSModUpdater.zip -d fsmup_temp

    # Create the destination directory if it doesn't exist
    mkdir -p updater
    mkdir deletable-temp

    # Copy the files to the destination directory
    shopt -s dotglob
    cp -r fsmup_temp/* updater/
     rsync -av --exclude='.updater.sh,FSModUpdater.zip,updater/' * deletable-temp/
 #.art/ deletable-temp/ && mv  .development/ deletable-temp/ && mv .old/ deletable-temp/ && mv Documents/ deletable-temp/ && mv FSMUP.py deletable-temp/ && mv .install.sh deletable-temp/ && mv run.sh  deletable-temp/
   rsync -av --exclude='.version.txt' updater/* ../FSModUpdater//
    

    # Clean up temporary files
    rm -rf fsmup_temp
    rm -rf deletable-temp
    rm FSModUpdater.zip
    rm -rf __MACOSX
    #rm -rf updater

    echo "Update complete!"
else
    echo "FSMUP is up to date."
fi
